# OS MINT

Локальный патч Soft Hub. В git не пушить.

Автоминт по одному или нескольким OpenSea slug / ссылкам.
Сеть: Robinhood 4663. Public не минтит. Остальные стадии — да.

## Сборка

```bash
python3 /Users/sprintray/codex_soft/soft-hub/scripts/build_plugin.py \
  /Users/sprintray/grok_soft/kuporh_mint \
  /Users/sprintray/grok_soft/kuporh_dist/os-mint-1.0.0.softhub.zip
```

В поле «Коллекции» кидай так:

```text
kuporh
https://opensea.io/collection/hoodiegroupies
```

Потолок `0` — только бесплатный WL. Для kuporh collab поставь `0.004`.
