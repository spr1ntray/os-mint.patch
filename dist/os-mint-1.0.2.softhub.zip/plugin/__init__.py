"""OpenSea slug mint plugin."""
